//
//  HCLRecorderController.h
//  recorder
//
//  Created by hcl on 16/5/6.
//  Copyright © 2016年 hclong. All rights reserved.
//

#import "ViewController.h"

@interface HCLRecorderController : ViewController

@end
