//
//  ViewController.h
//  recorder
//
//  Created by hcl on 16/5/6.
//  Copyright © 2016年 hclong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

